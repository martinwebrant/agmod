Cool Blue Readme
================

	There are 7 files inside of this zip file:
	1. cb_icon_steam.tga
	2. cb_icon_steam_disabled.tga
	3. cb_steam_logo.tga
	4. cb_valve_logo.tga
	5. TrackerScheme.res  (Please backup this file before overwriting it!)
	6. SteamRootDialog.res  (Please backup this file before overwriting it!)
	7. Readme.txt

Installation
================
--First backup TrackerScheme.res and SteamRootDialog.res.
--Then place items 1-5 into your Steam/Resource folder.
--Also place items 1-5 into Steam/SteamCache/youraddress@email.com/Counter-Strike/cstrike/Resource.
--Item 6 should be placed in your Steam/Steam folder.

Credits
================
Created by DuFF -- Duffman234@hotmail.com
Special thanks to SteamSkinners.GamerCentralClan.com for the tutorials.

Info
================
This item is marked freeware and may not be sold for any reason. It may, however, be redistributed as long as this readme is included.  All Steam/Valve images are copyrighted respectively.



