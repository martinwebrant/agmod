Name   : aghl steam skin
Autor  : Ludovic 'alba' Slangen
Date   : 29/09/03
Web    : http://www.albaworld.be/
Email  : alba@albaworld.be
Icq    : 129682359
Msn    : alba@albaworld.be

=======================================


Made for BuLLiT aghl steam skin contest :)

GL & HF with it ;)
